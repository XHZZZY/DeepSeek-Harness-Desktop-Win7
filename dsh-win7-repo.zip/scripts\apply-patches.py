#!/usr/bin/env python3
"""Apply unified diffs (patches/*.patch) onto a payload tree.

Usage:  python apply-patches.py <patch-dir> <work-dir> [--check]
Files are matched by the ``b/<path>`` side of each patch header.
"""
import sys, pathlib, re

HUNK = re.compile(r"^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@")

def read_lines(p):
    return p.read_bytes().decode("utf-8").splitlines(keepends=True)

def apply_one(patch_path, work, check):
    lines = patch_path.read_text(encoding="utf-8").splitlines(keepends=True)
    i = 0
    changed = 0
    while i < len(lines):
        if not lines[i].startswith("+++ "):
            i += 1
            continue
        target = lines[i][4:].strip().split("\t")[0]
        if target.startswith("b/"):
            target = target[2:]
        i += 1
        # skip "--- " already consumed above target line; collect hunks for this file
        hunks = []
        while i < len(lines) and not lines[i].startswith("+++ "):
            m = HUNK.match(lines[i])
            if not m:
                i += 1
                continue
            i += 1
            old, new = [], []
            while i < len(lines) and not lines[i].startswith("@@ ") and not lines[i].startswith("+++ "):
                t = lines[i]
                if t.startswith("\\"):
                    i += 1; continue
                if t.startswith("-"):
                    old.append(t[1:])
                elif t.startswith("+"):
                    new.append(t[1:])
                elif t.startswith(" "):
                    old.append(t[1:]); new.append(t[1:])
                else:
                    break
                i += 1
            hunks.append((old, new))
        f = work / target
        if not f.exists():
            print(f"  !! missing {target}")
            continue
        src = read_lines(f)
        for old, new in hunks:
            n = len(old)
            hit = -1
            for k in range(len(src) - n + 1):
                if src[k:k+n] == old:
                    hit = k; break
            if hit < 0:
                print(f"  !! context not found in {target} ({n} lines)")
                return False
            if not check:
                src[hit:hit+n] = new
            changed += 1
        if not check:
            f.write_bytes("".join(src).encode("utf-8"))
        print(f"  ok {target}: {len(hunks)} hunk(s)")
    return True

def main():
    patch_dir, work = pathlib.Path(sys.argv[1]), pathlib.Path(sys.argv[2])
    check = "--check" in sys.argv
    ok = True
    for p in sorted(patch_dir.glob("*.patch")):
        print(f"[patch] {p.name}")
        ok = apply_one(p, work, check) and ok
    print("RESULT:", "OK" if ok else "FAILED")
    return 0 if ok else 1

if __name__ == "__main__":
    sys.exit(main())
