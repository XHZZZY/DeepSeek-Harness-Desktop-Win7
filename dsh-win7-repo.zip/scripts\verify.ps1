<#
.SYNOPSIS  Sanity checks after a build (run before shipping).
#>
[CmdletBinding()]
param([string]$Root = "$PSScriptRoot\..")
$ErrorActionPreference = "Stop"
$Build = Join-Path $Root "build"
$fail = 0
function Check($name, [bool]$ok, $detail) {
  if ($ok) { Write-Host ("  [ok]   {0}  {1}" -f $name,$detail) }
  else     { Write-Host ("  [FAIL] {0}  {1}" -f $name,$detail) -ForegroundColor Red; $script:fail++ }
}

Write-Host "payload checks"
$exe = Join-Path $Build "payload\DeepSeek Harness.exe"
Check "runtime exe" (Test-Path $exe) $exe
if (Test-Path $exe) {
  $b=[IO.File]::ReadAllBytes($exe); $pe=[BitConverter]::ToInt32($b,0x3C)
  $sub=[BitConverter]::ToUInt16($b,$pe+24+0x48)
  Check "PE subsystem 6.1" ($sub -le 0x0601) ("{0}.{1}" -f ($sub -shr 8),($sub -band 0xFF))
}
$asar = Join-Path $Build "payload\resources\app.asar"
Check "app.asar" (Test-Path $asar) $(if(Test-Path $asar){"{0:N0} B" -f (Get-Item $asar).Length}else{"missing"})
foreach($f in @("main.js","preload-app.cjs","preload-welcome.cjs","win7-compat.cjs","win7-settings.js")){
  $p = Join-Path $Build "payload\resources\app.asar.unpacked\lib\$f"
  Check "unpacked $f" (Test-Path $p) ""
}
$main = Join-Path $Build "payload\resources\app.asar.unpacked\lib\main.js"
if (Test-Path $main) {
  $t = Get-Content $main -Raw
  Check "d3d9 switch"     ($t -match 'use-angle') ""
  Check "no GPU accel"    ($t -match 'disableHardwareAcceleration') ""
  Check "update gate"     ($t -match '__w7UpdateAllowed') ""
}

Write-Host "`nresult: $fail failure(s)"
if ($fail -gt 0) { exit 1 }
