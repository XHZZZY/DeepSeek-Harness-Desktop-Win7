# Troubleshooting

| Symptom | Cause | Fix |
|---|---|---|
| `Failed to parse header from …\app.asar`, blank window titled `Electron` | header rewritten with the wrong third field | use `patch-asar.py` (writes `headerSize - 4`) |
| `Unexpected token '}'` from `node --check lib/main.js` | asar extracted with `dataStart = 16 + jsonSize` | use `extract-asar.py` (`8 + headerSize`) |
| `Cannot bind an API on top of an existing property` | preload re-appended the whole file instead of a single marker block | re-apply `preload-*.patch` on the pristine file |
| `Unsupported/no-context (unsupported Electron runtime fingerprint)` | native addon still holds the upstream V8 string | run `03-patch-binaries.py` |
| `无法启动此程序，因为计算机中丢失 kxnt.DLL` | only `KexDll.dll` was registered, its companions are missing | copy the whole `Kex64\*.dll` set next to the exe |
| White window, `GPU process exited unexpectedly: exit_code=34` | GPU path broken on legacy VxD | `app.disableHardwareAcceleration()` (default) |
| `Command-manager process failed.` | `resources\runtime\cli` lacks `package.json` → ESM parsed as CJS | ship `files/runtime-cli/package.json` |
| `desktop welcome: Web authentication failed` | stale `%APPDATA%\@deepseek-ai\dsh-desktop` after repeated `taskkill` | delete that folder |
| `Office 预览不可用` | office-kit service failed to import | check `logs\host.log` for `failed to import`; ensure `index.js.patch` applied and LibreOffice installed |
| `wusa exit=-2145124329` (`0x80240017`) | WU applicability check says “not applicable” — **not** proof it is installed | the script falls back to `dism /add-package`; verify with `wmic qfe get HotFixID` |
| `dism exit=0` but no restart prompt | this update does not require a reboot | expected; check `RebootPending` to confirm |

## Log locations

```
%LOCALAPPDATA%\DeepSeek Harness\logs\host.log          main process
%LOCALAPPDATA%\DeepSeek Harness\logs\crash-*.log       crash reporter
%LOCALAPPDATA%\DeepSeek Harness\win7-compat.json       compatibility settings
%ProgramData%\DeepSeekHarness\kb-install.log           prerequisite updates
%ProgramData%\DeepSeekHarness\dism.log                 DISM fallback (verbose)
```
