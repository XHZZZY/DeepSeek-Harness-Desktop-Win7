# DeepSeek Harness Desktop — Windows 7 community port

Patches and build scripts that make the official **DeepSeek Harness desktop app
(0.2.2-rc.5, Electron 44 / Chromium 152 / Node 24)** run on **Windows 7 SP1 x64**.

This repository contains **only the patches, new source files and the installer
recipe** — no upstream binaries. `build.ps1` downloads the official packages and
reconstructs the whole thing locally.

---

## Why this is non-trivial

| Blocker | Why it fails on Win7 | What this repo does |
|---|---|---|
| Electron 44 binary | PE subsystem version is **10.0**; the Win7 loader refuses it before any code runs | swap in [electron-legacy](https://github.com/Alex313031/electron-legacy) `44.10.2`, whose subsystem is **5.2** |
| Bundled `node.exe` / `python.exe` | import `GetSystemTimePreciseAsFileTime`, `PathCch*`, `WaitOnAddress` … missing on Win7 | install **VxKex API Extensions 1.2.2** and write the IFEO `VerifierDlls=kexdll.dll` entry |
| GPU process | `d3d11` device removed → `exit_code=34` → white window | `app.disableHardwareAcceleration()` + `--use-angle=d3d9` fallback |
| Title bar | `titleBarStyle:"hidden"` + `titleBarOverlay` need Win10 1809+; Win7 silently falls back to the Aero frame | `frame:false, thickFrame:false` + self-drawn min/max/close via IPC |
| Native addons | `node-addon-require-builtin` embeds a V8 version string + Node ABI triple | rewrite both in place to `15.2.124.45-electron.0` / `(24,22,2)` |
| DPAPI / sandbox | Win7 has no nested jobs; `CREATE_BREAKAWAY_FROM_JOB` returns `err=5` | run with full permissions (restricted mode is structurally unavailable) |
| Office → PDF | bundled LibreOffice kit needs `BCryptKeyDerivation` (Win8+) | fall back to a system LibreOffice `soffice.com --headless` |

## Requirements (build machine)

* Windows 10/11 x64 (the payload is cross-assembled; you do **not** need Win7 to build)
* PowerShell 5.1+, Python 3.9+
* [7-Zip](https://www.7-zip.org/) (`7z.exe`)
* [Inno Setup 6.7.4](https://jrsoftware.org/isdl.php) — `ISCC.exe`
* optional: `rcedit-x64.exe` (sets icon/product version on the swapped binary)

## Quick start

```powershell
git clone <this repo> dsh-win7
cd dsh-win7
.\scripts\build.ps1                       # full build
# or reuse already downloaded artefacts:
.\scripts\build.ps1 -SkipFetch
# or point at local copies (offline):
.\scripts\build.ps1 -RuntimeZip D:\electron-v44.10.2-win32-x64.zip -PayloadExe D:\dsh-setup.exe
```

Output: `build\output\DeepSeekHarness-win7-x64-Setup.exe` (~1.1 GB).

## Pipeline

```
01-fetch-runtime.ps1   GitHub  -> build\runtime\electron.exe      (verifies PE subsystem <= 6.1)
02-fetch-payload.ps1   nightly.yml -> build\app\                  (7z x installer, then app-64.7z)
extract-asar.py        app.asar   -> build\extract\               (ASAR parser, offsets relative to dataStart)
apply-patches.py       patches/*.patch -> build\extract\          (unified diff, context matched)
03-patch-binaries.py   build\app  -> native addon fingerprints
patch-asar.py          rebuild app.asar                            (3 files unpacked, office-kit inlined)
04-assemble.ps1        build\runtime + build\app -> build\payload  (exe swap, licences, prereqs)
verify.ps1             PE header / unpacked files / patched markers
05-build-installer.ps1 ISCC -> build\output\*.exe
```

## Repository layout

```
patches/                 unified diffs against the official rc.5 sources
  main.js.patch            GPU switch, frameless windows, worker execPath, update gate, crash reporter
  preload-app.cjs.patch    window.__DSH_WIN7__ bridge + frameless window controls
  preload-welcome.cjs.patch same controls for the welcome window
  index.js.patch           office-kit: LibreOffice fallback for PDF export
files/
  lib/win7-compat.cjs      config store, GPU policy, IPC (open logs/config/export/clear/relaunch), window control
  lib/win7-settings.js     “兼容设置” panel injected into the sidebar
  runtime-cli/package.json {"type":"module"} - the CLI is ESM, rc.5 ships it without it
  prereq/install-kb.cmd    wusa -> DISM fallback, ordered KB application, reboot marker
  installer/               dsh_win7.iss, chinese.isl, wizard.bmp, small.bmp
  licenses/                CHANGES / PRIVACY / THIRD-PARTY-NOTICES / VxKex-NOTICE
scripts/                 build pipeline (see above)
docs/                    architecture notes, troubleshooting
```

## What still does not work (honest list)

* **Restricted sandbox mode** — Win7 has no nested jobs, `AssignProcessToJobObject` fails with 5.
  Every command runs with full permissions.
* **Bundled Python/Node without VxKex** — they die with `0xC0000139` until the Kex DLLs sit next
  to the executable *and* the IFEO entry exists.
* **Office preview for PDF** — falls back to a system LibreOffice install; the bundled kit’s
  exporter cannot load on Win7.
* **Native modules built for Node ≥ 18 ABI** — must be rebuilt for `electron 44` ABI.

## Compliance

* Upstream DeepSeek Harness, Electron, Chromium, Node, Python and LibreOffice keep their own
  licences — see `files/licenses/THIRD-PARTY-NOTICES.txt`. Nothing here re-licenses them.
* **This is not an official DeepSeek build.** It is a community compatibility port; do not
  report its bugs upstream.
* VxKex API Extensions ships **without a licence file** upstream (`license: null`), i.e. all
  rights reserved. It is therefore an *optional component* of the installer, not bundled code
  in this repository — the build downloads it separately.
* No API keys, tokens or session data are collected or uploaded. See
  `files/licenses/PRIVACY-WIN7.zh.txt`.
