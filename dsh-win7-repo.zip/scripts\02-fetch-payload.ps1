<#
.SYNOPSIS  Download the official DeepSeek Harness desktop build and unpack app.asar.
.DESCRIPTION
  Reads the nightly feed, downloads the NSIS installer, then extracts it with
  7-Zip in two steps (installer -> $PLUGINSDIR/app-64.7z -> tree).
  Produces:  build\app\  (resources\app.asar + resources\app.asar.unpacked + runtime\)
#>
[CmdletBinding()]
param(
  [string]$Feed    = "https://download.deepseek.com/dsh-desk/feeds/win-x64/nightly.yml",
  [string]$Version = "",
  [string]$OutDir  = "$PSScriptRoot\..\build",
  [string]$LocalExe,
  [string]$SevenZip = "C:\Program Files\7-Zip\7z.exe"
)
$ErrorActionPreference = "Stop"
New-Item -ItemType Directory -Force -Path $OutDir | Out-Null

$exe = $LocalExe
if (-not $exe) {
  Write-Host "[1/4] reading feed $Feed"
  $yml = (Invoke-WebRequest -Uri $Feed -UseBasicParsing).Content
  $ver = if ($Version) { $Version } else { ([regex]'(?m)^version:\s*(\S+)').Match($yml).Groups[1].Value }
  $rel = ([regex]'(?m)^path:\s*(\S+)').Match($yml).Groups[1].Value
  $size= ([regex]'(?m)^size:\s*(\d+)').Match($yml).Groups[1].Value
  if (-not $rel) { throw "cannot parse 'path:' from feed" }
  $url = "https://download.deepseek.com" + $rel
  $exe = Join-Path $OutDir (Split-Path $rel -Leaf)
  Write-Host "      version=$ver size=$size"
  Write-Host "      url=$url"
  if (-not (Test-Path $exe)) { Invoke-WebRequest -Uri $url -OutFile $exe -UseBasicParsing }
} else { Write-Host "[1/4] using $exe" }

if (-not (Test-Path $SevenZip)) { throw "7-Zip not found: $SevenZip" }

Write-Host "[2/4] extracting installer"
$stage = Join-Path $OutDir "stage"
if (Test-Path $stage) { Remove-Item $stage -Recurse -Force }
& $SevenZip x $exe "-o$stage" -y | Out-Null

Write-Host "[3/4] locating app-64.7z"
$inner = Get-ChildItem $stage -Filter "app-64.7z" -Recurse | Select-Object -First 1
if (-not $inner) { throw "app-64.7z not found under $stage" }

Write-Host "[4/4] extracting app tree"
$app = Join-Path $OutDir "app"
if (Test-Path $app) { Remove-Item $app -Recurse -Force }
& $SevenZip x $inner.FullName "-o$app" -y | Out-Null

$asar = Join-Path $app "resources\app.asar"
if (-not (Test-Path $asar)) { throw "app.asar missing - layout changed?" }
Write-Host ("OK -> {0}  ({1:N0} B)" -f $asar,(Get-Item $asar).Length)
