# Architecture notes

## ASAR container (the thing that bit us most)

```
uint32 magic = 4
uint32 headerSize          # 8 + jsonSize (+padding)
uint32 headerStringSize    # headerSize - 4
uint32 jsonSize
<json header>              # file tree, offsets are relative to dataStart
<payload blob>
dataStart = 8 + headerSize          # NOT 16 + jsonSize
```

Two traps:

1. **`dataStart`**. Parsing it as `16 + jsonSize` is off by the padding bytes and silently
   shifts every extracted file by 1–3 bytes. `node --check main.js` then reports a
   `Unexpected token '}'` at EOF, which reads like a patch bug.
2. **Header rewrite**. When repacking, the third field must be `headerSize - 4`, not the JSON
   length. Getting it wrong makes Electron print `Failed to parse header from …\app.asar`
   and fall back to a blank window titled `Electron`.

## `unpacked` semantics

A file flagged `"unpacked": true` is read **from disk at runtime**. Two consequences:

* shipping an updated `app.asar` without the matching file under `app.asar.unpacked\` changes
  nothing (silently!) — the disk copy wins;
* an **empty** unpacked directory shadows the in-asar entry, so a stale empty folder is worse
  than no folder at all.

Which is why this port:

* keeps `lib/main.js`, `lib/preload-*.cjs` unpacked (easy to inspect/patch);
* **inlines** `dsh-office-kit` back into the asar — its ESM imports resolve siblings from the
  asar, so unpacking it breaks with `Cannot find package '@deepseek-ai/schemastery'`.

## Window chrome on Win7

`titleBarStyle: "hidden"` implies the Windows Control Overlay, which needs 10.0.1809+.
On Win7 the flag is accepted but the caption falls back to Aero. The port therefore builds
both windows with `frame: false, thickFrame: false` and draws min/max/close itself:

* renderer (`preload-app.cjs`) injects `div#dsh-win7-controls` with `-webkit-app-region: no-drag`;
* clicks go through `ipcRenderer.send("dsh-win7-window-control", action)`;
* `win7-compat.cjs` performs the action and pushes `dsh-win7-window-state` back so the
  maximize glyph can flip to “restore”.

`thickFrame: false` is a trade: it removes the Aero border **and** the native minimize
animation (both are the same `WS_THICKFRAME` feature). Native animation was deliberately
dropped.

## Update channel is opt-in

The upstream updater runs as soon as the app is packaged. On Win7 that is undesirable
(fresh installs would immediately try to fetch an Electron-44 build that cannot boot).
`win7-compat.json` holds `autoUpdate` (default **false**, `CONFIG_SCHEMA = 2`); when false the
coordinator’s `enabled()` gate returns early, so no feed request is made at all. The
compatibility panel exposes the switch and hides it behind a restart hint.

## Reboot marker

`install-kb.cmd` records every `wusa`/`dism` exit code into
`%ProgramData%\DeepSeekHarness\kb-install.log` and writes
`kb-restart.needed` **only** for `3010` / `1641`. `[Code]`’s `NeedRestartAfterPatch()` checks
for that file, so the finish page offers “restart now” exactly when the servicing stack
actually asked for a reboot — not merely because a KB component was selected.
