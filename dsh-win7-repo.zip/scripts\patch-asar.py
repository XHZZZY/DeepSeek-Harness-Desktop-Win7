#!/usr/bin/env python3
"""Rebuild resources/app.asar for the Win7 build.

  * lib/main.js, lib/preload-app.cjs, lib/preload-welcome.cjs -> unpacked (read from disk)
  * dsh/node_modules/@deepseek-ai/dsh-office-kit/lib/index.js -> inlined rewrite
  * node-addon-require-builtin prebuilt .node -> Electron 44.10.2 fingerprint

Usage:
  python patch-asar.py <src-asar> <patched-dir> <out-asar> <unpacked-out-dir>
    <patched-dir> holds lib/main.js, lib/preload-app.cjs, lib/preload-welcome.cjs,
    office-kit-index.js and the node-addon .node patched by 03-patch-binaries.py
"""
import sys, json, struct, pathlib, shutil

UNPACKED = ["/lib/main.js", "/lib/preload-app.cjs", "/lib/preload-welcome.cjs"]
OFFICE = "/dsh/node_modules/@deepseek-ai/dsh-office-kit/lib/index.js"

def read_asar(path):
    b = path.read_bytes()
    magic, hdr_size, str_size, json_size = struct.unpack("<IIII", b[:16])
    assert magic == 4, f"bad asar magic {magic}"
    data_start = 8 + hdr_size
    header = json.loads(b[16:16 + json_size].decode("utf-8"))
    return b, header, data_start

def walk(node, prefix=""):
    for name, e in node.get("files", {}).items():
        p = prefix + "/" + name
        if "files" in e:
            yield from walk(e, p)
        else:
            yield p, e

def get_entry(header, path):
    node = header
    for part in path.strip("/").split("/"):
        node = node["files"][part]
    return node

def main():
    src, pdir, out, udir = (pathlib.Path(a) for a in sys.argv[1:5])
    pdir, udir = pathlib.Path(sys.argv[2]), pathlib.Path(sys.argv[4])
    b, header, data_start = read_asar(src)

    entries = dict(walk(header))
    data = {}          # path -> bytes payload
    for p, e in entries.items():
        off, size = int(e.get("offset", 0)), int(e.get("size", 0))
        data[p] = b[data_start + off: data_start + off + size]

    # 1) replacements, then mark unpacked
    for p in UNPACKED:
        local = pdir / p.lstrip("/")
        data[p] = local.read_bytes()
        print(f"  unpacked {p} <- {len(data[p])} B")
    # 2) inline office-kit (must stay inside asar: it resolves siblings from asar)
    ok_src = pdir / "office-kit-index.js"
    if OFFICE in data and ok_src.exists():
        data[OFFICE] = ok_src.read_bytes()
        print(f"  inlined {OFFICE} <- {len(data[OFFICE])} B")

    # 3) rewrite every non-unpacked entry sequentially, keep unpacked as placeholders
    blob = bytearray()
    for p in sorted(data):
        e = entries[p]
        e.pop("integrity", None)
        if p in UNPACKED:
            e["unpacked"] = True
            e.pop("offset", None)
            e.pop("size", None)
            continue
        e.pop("unpacked", None)
        e["offset"] = str(len(blob))
        e["size"] = len(data[p])
        blob += data[p]

    js = json.dumps(header, separators=(",", ":")).encode("utf-8")
    pad = (4 - (len(js) % 4)) % 4
    js_padded = js + b"\0" * pad
    dh = 8 + len(js_padded)
    head = struct.pack("<IIII", 4, dh, dh - 4, len(js_padded))
    out.write_bytes(head + js_padded + bytes(blob))
    print(f"  asar: {out} {out.stat().st_size} B (header {dh}, data {len(blob)})")

    for p in UNPACKED:
        dst = udir / p.lstrip("/")
        dst.parent.mkdir(parents=True, exist_ok=True)
        dst.write_bytes(data[p])
        print(f"  wrote {dst}")

if __name__ == "__main__":
    main()
