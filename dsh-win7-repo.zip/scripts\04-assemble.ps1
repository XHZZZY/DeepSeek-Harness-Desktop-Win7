<#
.SYNOPSIS  Turn build\app + patched lib files into a shippable payload tree.
.DESCRIPTION
  1. copy the official tree, drop the official electron binary
  2. drop in the electron-legacy exe under the product name (icon + version)
  3. copy unpacked lib files, licences, prerequisites, tools
#>
[CmdletBinding()]
param(
  [string]$Root     = "$PSScriptRoot\..",
  [string]$AppDir   = "$PSScriptRoot\..\build\app",
  [string]$Runtime  = "$PSScriptRoot\..\build\runtime",
  [string]$Payload  = "$PSScriptRoot\..\build\payload",
  [string]$ProductName = "DeepSeek Harness",
  [string]$Rcedit
)
$ErrorActionPreference = "Stop"
$files = Join-Path $Root "files"

if (Test-Path $Payload) { Remove-Item $Payload -Recurse -Force }
Write-Host "[1/4] copying app tree"
Copy-Item $AppDir $Payload -Recurse -Force

Write-Host "[2/4] swapping runtime binary"
$src = Join-Path $Runtime "electron.exe"
if (-not (Test-Path $src)) { throw "missing $src (run 01-fetch-runtime.ps1)" }
$dst = Join-Path $Payload "$ProductName.exe"
Get-ChildItem $Payload -Filter "*.exe" -File | Remove-Item -Force
Copy-Item $src $dst -Force
if ($Rcedit -and (Test-Path $Rcedit)) {
  & $Rcedit $dst --set-file-version "0.2.2.0" --set-version-string "ProductName" $ProductName `
      --set-version-string "FileDescription" $ProductName --set-version-string "CompanyName" "community build" | Out-Null
  Write-Host "      rcedit applied"
} else { Write-Warning "rcedit not supplied - binary keeps electron icon/version" }

Write-Host "[3/4] copying patched lib files"
$libOut = Join-Path $Payload "resources\app.asar.unpacked\lib"
New-Item -ItemType Directory -Force -Path $libOut | Out-Null
Copy-Item (Join-Path $files "lib\*.cjs") $libOut -Force
Copy-Item (Join-Path $files "lib\*.js")  $libOut -Force
$cliPkg = Join-Path $Payload "resources\runtime\cli\package.json"
if (Test-Path (Split-Path $cliPkg)) { Copy-Item (Join-Path $files "runtime-cli\package.json") $cliPkg -Force }

Write-Host "[4/4] copying licences / prerequisites"
Copy-Item (Join-Path $files "licenses\*") (Join-Path $Payload "licenses") -Force -ErrorAction SilentlyContinue
New-Item -ItemType Directory -Force -Path (Join-Path $Payload "prereq\kb") | Out-Null
Copy-Item (Join-Path $files "prereq\install-kb.cmd") (Join-Path $Payload "prereq\kb\") -Force

Write-Host ("OK -> {0}" -f $Payload)
