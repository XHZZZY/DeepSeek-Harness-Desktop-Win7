﻿; ============================================================================



#define AppName "DeepSeek Harness"

#define AppVersion "0.2.2-rc.5"

#define AppPublisher "Hangzhou DeepSeek Artificial Intelligence Co., Ltd."

#define AppExe "DeepSeek Harness.exe"

#define PayloadDir "E:\WorkSpace\_payload"



[Setup]

AppId={{8F3C1A2E-5D7B-4E9A-9C21-5A1B2C3D4E5F}

LicenseFile={#PayloadDir}\licenses\LICENSE.txt

InfoBeforeFile={#PayloadDir}\licenses\CHANGES-WIN7.en.txt

AppName={#AppName}

AppVersion={#AppVersion}

AppVerName={#AppName} {#AppVersion} (Windows 7 x64)

AppPublisher={#AppPublisher}

AppPublisherURL=https://www.deepseek.com/

AppSupportURL=https://www.deepseek.com/

DefaultDirName={autopf}\DeepSeek Harness

DefaultGroupName=DeepSeek Harness

DisableProgramGroupPage=yes

DisableDirPage=no

AllowNoIcons=yes

OutputDir={#PayloadDir}\..\_innosetup\output

OutputBaseFilename=DeepSeekHarness-{#AppVersion}-win7-x64-Setup

SetupIconFile={#PayloadDir}\resources\\assets\\icon.ico

WizardImageStretch=yes

WizardImageFile=E:\WorkSpace\_innosetup\wizard.bmp

WizardSmallImageFile=E:\WorkSpace\_innosetup\small.bmp

WizardStyle=modern

WizardSizePercent=100

Compression=lzma2/max

SolidCompression=no

LZMAUseSeparateProcess=yes

InternalCompressLevel=max

ArchitecturesAllowed=x64compatible

ArchitecturesInstallIn64BitMode=x64compatible

MinVersion=6.1sp1

PrivilegesRequired=admin

UninstallDisplayIcon={app}\{#AppExe}

UninstallDisplayName={#AppName}

CloseApplications=no

RestartApplications=no

RestartIfNeededByRun=yes

SetupLogging=yes

UsePreviousAppDir=yes

UsePreviousTasks=yes

VersionInfoVersion=1.0.0

VersionInfoProductName={#AppName}

VersionInfoProductVersion=1.0.0

VersionInfoCompany={#AppPublisher}

VersionInfoDescription=DeepSeek Harness Setup (Windows 7 x64)



ShowLanguageDialog=no

LanguageDetectionMethod=locale



[Languages]

Name: "zh"; MessagesFile: "chinese.isl"

Name: "en"; MessagesFile: "compiler:Default.isl"



[CustomMessages]

en.AdditionalIcons=Additional icons(&I):

en.CompMain=DeepSeek Harness main program (required)

en.CompPS=PowerShell 5.1 and .NET Framework 4.8 (prerequisites)
en.CompKb1=KB4474419 (SHA-2 code signing support)
en.CompKb2=KB4490628 (SHA-2 servicing stack update)
en.CompKb3=KB2533623 (DLL loading security fix)
en.CompKb4=KB2670838 (Platform Update / D3D11.1)

en.CompTools=Optional toolchain: Git, 7-Zip, LibreOffice

en.CompVxKex=VxKex compatibility runtime (required on Windows 7)

en.TaskAutoStart=Start DeepSeek Harness at logon(&S)

en.TaskDesktopIcon=Create a desktop shortcut(&D)

en.RunApp=Launch {#AppName} after setup(&R)

en.NeedReboot=Restart the computer after setup(&E)



zh.AdditionalIcons=附加图标(&I)：

zh.CompMain=DeepSeek Harness 主程序（必需）

zh.CompPS=PowerShell 5.1 与 .NET Framework 4.8（先决包）
zh.CompKb1=KB4474419（SHA-2 代码签名支持）
zh.CompKb2=KB4490628（SHA-2 服务栈更新）
zh.CompKb3=KB2533623（DLL 加载安全补丁）
zh.CompKb4=KB2670838（Platform Update / D3D11.1）

zh.CompTools=可选工具链：Git、7-Zip、LibreOffice

zh.CompVxKex=VxKex 兼容层运行库（Windows 7 必需）

zh.TaskAutoStart=开机时自动启动 DeepSeek Harness(&S)

zh.TaskDesktopIcon=创建桌面快捷方式(&D)

zh.RunApp=安装完成后运行 {#AppName}(&R)

zh.NeedReboot=安装完成后重新启动计算机(&E)



[Tasks]

Name: "autostart"; Description: "{cm:TaskAutoStart}"; GroupDescription: "{cm:AdditionalIcons}"

Name: "desktopicon"; Description: "{cm:TaskDesktopIcon}"; GroupDescription: "{cm:AdditionalIcons}"



[Components]

Name: "main"; Description: "{cm:CompMain}"; Types: full compact custom; Flags: fixed

Name: "vxkex"; Description: "{cm:CompVxKex}"; Types: full compact custom

Name: "tools"; Description: "{cm:CompTools}"; Types: full



Name: "ps"; Description: "{cm:CompPS}"; Types: full custom; Flags: fixed

Name: "kb1"; Description: "{cm:CompKb1}"; Types: full custom

Name: "kb2"; Description: "{cm:CompKb2}"; Types: full custom

Name: "kb3"; Description: "{cm:CompKb3}"; Types: full custom

Name: "kb4"; Description: "{cm:CompKb4}"; Types: full custom



[InstallDelete]

Type: filesandordirs; Name: "{app}\_vxkex"



[Dirs]

Name: "{localappdata}\DeepSeek Harness\cli-bin"



[Files]

Source: "{#PayloadDir}\licenses\CHANGES-WIN7.zh.ansi.txt"; DestDir: "{tmp}"; Flags: dontcopy

; ---- application payload ----

Source: "{#PayloadDir}\*"; DestDir: "{app}"; Excludes: "\prereq\*,\_vxkex\*,*.bak-jobpatch,*.bak-sbx,*.tmp-jobpatch"; Flags: ignoreversion recursesubdirs createallsubdirs



Source: "{#PayloadDir}\resources\tray.ico"; DestDir: "{app}\resources"; Flags: ignoreversion

; ---- VxKex runtime (installed to its canonical location) ----

Source: "{#PayloadDir}\_vxkex\*"; DestDir: "{commonpf}\VxKex"; Excludes: "KexDll.dll"; Flags: recursesubdirs createallsubdirs

Source: "{#PayloadDir}\_vxkex\KexDll.dll"; DestDir: "{sys}"; Flags: 64bit

; KexDll.dll resolves its companion modules (KxNt.dll, KxBase.dll, ...) through the

; standard DLL search path. Placing them beside the executable makes the layer

; self-contained and avoids touching PATH or System32 for the runtimes.

Source: "{#PayloadDir}\_vxkex\Kex64\*.dll"; DestDir: "{app}"; Flags: ignoreversion

Source: "{#PayloadDir}\_vxkex\Kex64\*.dll"; DestDir: "{app}\resources\app.asar.unpacked\dsh\node_modules\@deepseek-ai\libreoffice-kit-win32-x64\bin"; Flags: ignoreversion

Source: "{#PayloadDir}\_vxkex\KexDll.dll"; DestDir: "{app}\resources\app.asar.unpacked\dsh\node_modules\@deepseek-ai\libreoffice-kit-win32-x64\bin"; Flags: 

Source: "{#PayloadDir}\_vxkex\Kex64\*.dll"; DestDir: "{app}\resources\runtime\primary-runtime\dependencies\python"; Flags: ignoreversion

Source: "{#PayloadDir}\_vxkex\Kex64\*.dll"; DestDir: "{app}\resources\runtime\primary-runtime\dependencies\node\bin"; Flags: ignoreversion

Source: "{#PayloadDir}\_vxkex\KexDll.dll"; DestDir: "{app}\resources\runtime\primary-runtime\dependencies\python"; Flags: 

Source: "{#PayloadDir}\_vxkex\KexDll.dll"; DestDir: "{app}\resources\runtime\primary-runtime\dependencies\node\bin"; Flags: 

; ---- prerequisite packages (extracted only when the component is selected) ----

Source: "{#PayloadDir}\prereq\ndp48.exe"; DestDir: "{tmp}"; Flags: deleteafterinstall; Components: ps

Source: "{#PayloadDir}\prereq\wmf51_win7.msu"; DestDir: "{tmp}"; Flags: deleteafterinstall; Components: ps

Source: "{#PayloadDir}\prereq\7z2201-x64.msi"; DestDir: "{tmp}"; Flags: deleteafterinstall; Components: tools

Source: "{#PayloadDir}\prereq\Git-2.46.2-64-bit.exe"; DestDir: "{tmp}"; Flags: deleteafterinstall; Components: tools

Source: "{#PayloadDir}\prereq\LibreOffice_7.3.7.2_Win_x64.msi"; DestDir: "{tmp}"; Flags: deleteafterinstall; Components: tools

Source: "{#PayloadDir}\prereq\kb\Windows6.1-KB4474419-v3-x64.msu"; DestDir: "{tmp}\kb"; Flags: deleteafterinstall skipifsourcedoesntexist; Components: kb1
Source: "{#PayloadDir}\prereq\kb\Windows6.1-KB4490628-x64.msu"; DestDir: "{tmp}\kb"; Flags: deleteafterinstall skipifsourcedoesntexist; Components: kb2
Source: "{#PayloadDir}\prereq\kb\Windows6.1-KB2533623-x64.msu"; DestDir: "{tmp}\kb"; Flags: deleteafterinstall skipifsourcedoesntexist; Components: kb3
Source: "{#PayloadDir}\prereq\kb\Windows6.1-KB2670838-x64.msu"; DestDir: "{tmp}\kb"; Flags: deleteafterinstall skipifsourcedoesntexist; Components: kb4
Source: "{#PayloadDir}\prereq\kb\install-kb.cmd"; DestDir: "{tmp}\kb"; Flags: deleteafterinstall; Components: kb1 kb2 kb3 kb4

Source: "{#PayloadDir}\tools\office-pdf.cmd"; DestDir: "{localappdata}\DeepSeek Harness\cli-bin"; Flags: ignoreversion; Components: tools



[Icons]

Name: "{autoprograms}\DeepSeek Harness"; Filename: "{app}\{#AppExe}"; WorkingDir: "{app}"

Name: "{autodesktop}\DeepSeek Harness"; Filename: "{app}\{#AppExe}"; WorkingDir: "{app}"; Tasks: desktopicon



[Registry]

Root: HKLM; Subkey: "SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\libreoffice-kit.exe"; Flags: deletekey dontcreatekey

Root: HKCU; Subkey: "Software\Microsoft\Windows\CurrentVersion\Run"; ValueType: string; ValueName: "DeepSeekHarness"; ValueData: """{app}\{#AppExe}"""; Flags: uninsdeletevalue; Tasks: autostart



[Run]

Filename: "{tmp}\ndp48.exe"; Parameters: "/q /norestart"; StatusMsg: "Installing .NET Framework 4.8 ..."; Flags: waituntilterminated; Components: ps; Check: CheckDotNet

Filename: "{sys}\wusa.exe"; Parameters: """{tmp}\wmf51_win7.msu"" /quiet /norestart"; StatusMsg: "Installing Windows Management Framework 5.1 ..."; Flags: waituntilterminated; Components: ps; Check: CheckPs51

Filename: "{sys}\msiexec.exe"; Parameters: "/i ""{tmp}\7z2201-x64.msi"" /qn /norestart"; StatusMsg: "Installing 7-Zip ..."; Flags: waituntilterminated; Components: tools; Check: Check7z

Filename: "{tmp}\Git-2.46.2-64-bit.exe"; Parameters: "/VERYSILENT /NORESTART /NOCANCEL /SP- /CLOSEAPPLICATIONS /COMPONENTS=""gitlfs,assoc,assoc_sh"""; StatusMsg: "Installing Git for Windows ..."; Flags: waituntilterminated; Components: tools; Check: CheckGit

Filename: "{sys}\msiexec.exe"; Parameters: "/i ""{tmp}\LibreOffice_7.3.7.2_Win_x64.msi"" /qn /norestart"; StatusMsg: "Installing LibreOffice 7.3 ..."; Flags: waituntilterminated; Components: tools; Check: CheckLO
Filename: "{sys}\cmd.exe"; Parameters: "/c ""{tmp}\kb\install-kb.cmd"""; StatusMsg: "正在安装所选的 Windows 更新补丁…"; Flags: waituntilterminated runhidden; Components: kb1 kb2 kb3 kb4; Check: CheckAnyKb

Filename: "{app}\{#AppExe}"; Description: "{cm:RunApp}"; Flags: nowait postinstall skipifsilent



; ---- 系统补丁（仅当系统缺失且包内带了 MSU 时才安装）----





; ---- 完成页：可选「立即重启」----

Filename: "{cmd}"; Parameters: "/c shutdown /r /t 15 /d p:2:4"; Description: "立即重启计算机以完成补丁安装(&R)"; Flags: postinstall nowait skipifsilent runhidden unchecked; Check: NeedRestartAfterPatch



[UninstallDelete]

Type: filesandordirs; Name: "{localappdata}\DeepSeek Harness\cli-bin"



[UninstallRun]

Filename: "{sys}\reg.exe"; Parameters: "delete ""HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\{#AppExe}"" /f"; Flags: runhidden; RunOnceId: "DelIFEOApp"

Filename: "{sys}\reg.exe"; Parameters: "delete ""HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\node.exe"" /f"; Flags: runhidden; RunOnceId: "DelIFEONode"



[Code]

const

  KEX_KEY_ROOT = 'SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\';



var

  UpdateRan: Boolean;



function RegReadStr(Root: Integer; const SubKey, ValueName: String; var Value: String): Boolean;

var

  Tmp: String;

begin

  Result := RegQueryStringValue(Root, SubKey, ValueName, Tmp);

  if Result then Value := Tmp;

end;



function HasDotNet48: Boolean;

var

  Rel: Cardinal;

begin

  Result := RegQueryDWordValue(HKEY_LOCAL_MACHINE,

    'SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full', 'Release', Rel) and (Rel >= 528040);

end;



function HasPS51: Boolean;

var

  V: String;

begin

  Result := RegReadStr(HKEY_LOCAL_MACHINE,

    'SOFTWARE\Microsoft\PowerShell\3\PowerShellEngine', 'PowerShellVersion', V) and (V >= '5.1');

end;



function Has7z: Boolean;

begin

  Result := FileExists(ExpandConstant('{commonpf}\7-Zip\7z.exe'));

end;



function HasGit: Boolean;

begin

  Result := FileExists(ExpandConstant('{commonpf}\Git\cmd\git.exe'));

end;



function HasLibreOffice: Boolean;

begin

  Result := FileExists(ExpandConstant('{commonpf}\LibreOffice\program\soffice.exe'));

end;



{ Enable the VxKex API layer for one executable. Mirrors what KexCfg.exe /ENABLE:1 writes. }

procedure EnableVxKex(const ExeFullPath: String);

var

  Leaf, Sub: String;

begin

  Leaf := ExtractFileName(ExeFullPath);

  Sub := KEX_KEY_ROOT + Leaf;

  RegWriteDWordValue(HKEY_LOCAL_MACHINE, Sub, 'UseFilter', 1);

  Sub := Sub + '\VxKex_DSHWIN7X64';

  RegWriteStringValue(HKEY_LOCAL_MACHINE, Sub, 'FilterFullPath', ExeFullPath);

  RegWriteDWordValue(HKEY_LOCAL_MACHINE, Sub, 'KEX_DisableForChild', 0);

  RegWriteDWordValue(HKEY_LOCAL_MACHINE, Sub, 'KEX_DisableAppSpecific', 0);

  RegWriteDWordValue(HKEY_LOCAL_MACHINE, Sub, 'KEX_WinVerSpoof', 0);

  RegWriteDWordValue(HKEY_LOCAL_MACHINE, Sub, 'KEX_StrongVersionSpoof', 0);

  RegWriteDWordValue(HKEY_LOCAL_MACHINE, Sub, 'KEX_DisableConsoleEnhancements', 0);

  RegWriteDWordValue(HKEY_LOCAL_MACHINE, Sub, 'KEX_TlsForceEnabledProtocols', 0);

  RegWriteDWordValue(HKEY_LOCAL_MACHINE, Sub, 'KEX_TlsForceDisabledProtocols', 0);

  RegWriteStringValue(HKEY_LOCAL_MACHINE, Sub, 'KEX_DllRewriteEntries', '');

  RegWriteStringValue(HKEY_LOCAL_MACHINE, Sub, 'KEX_DllRewriteExemptions', '');

  RegWriteDWordValue(HKEY_LOCAL_MACHINE, Sub, 'GlobalFlag', $00000100);

  RegWriteDWordValue(HKEY_LOCAL_MACHINE, Sub, 'VerifierFlags', $80000000);

  RegWriteStringValue(HKEY_LOCAL_MACHINE, Sub, 'VerifierDlls', 'kexdll.dll');

end;



function AddToUserPath(const Entry: String): Boolean;

var

  Cur: String;

  Next: String;

  Low: String;

begin

  Low := Lowercase(Cur);

  Result := False;

  if RegQueryStringValue(HKCU, 'Environment', 'Path', Cur) then

    Low := Lowercase(Cur)

  else

    Cur := '';

  if Low <> '' then

    if Pos(Lowercase(Entry), Low) > 0 then

      Exit;

  if Cur = '' then

    Next := Entry

  else

  begin

    Next := Cur;

    if Next[Length(Next)] <> ';' then

      Next := Next + ';';

    Next := Next + Entry;

  end;

  Result := RegWriteExpandStringValue(HKCU, 'Environment', 'Path', Next);

end;



function ProvisionDshCommand(): Boolean;

var

  Dir: String;

  Shim: String;

  AppExe: String;

  CliJs: String;

begin

  Result := False;

  Dir := ExpandConstant('{localappdata}\DeepSeek Harness\cli-bin');

  AppExe := ExpandConstant('{app}\{#AppExe}');

  CliJs := ExpandConstant('{app}\resources\app.asar\dsh\node_modules\@deepseek-ai\dsh-desktop-host\lib\cli.js');

  ForceDirectories(Dir);

  if not DirExists(Dir) then

    Exit;



  Shim := '@echo off' + #13#10

    + 'setlocal' + #13#10

    + 'set ELECTRON_RUN_AS_NODE=1' + #13#10

    + '"' + AppExe + '" --expose-internals "' + CliJs + '" %*' + #13#10;

  if not SaveStringToFile(Dir + '\dsh.cmd', Shim, False) then

    Exit;



  { Same keys the built-in command manager writes, so the UI reports "installed". }

  RegWriteStringValue(HKCU, 'Software\DeepSeekHarness\Command', 'Directory', Dir);

  RegWriteDWordValue(HKCU, 'Software\DeepSeekHarness\Command', 'PathWasAbsent', 0);

  RegWriteDWordValue(HKCU, 'Software\DeepSeekHarness\Command', 'RetainedEntries', 1);

  AddToUserPath(Dir);

  Result := True;

end;



procedure NormalizeUserPath;

var

  P, Item, Acc, Rest: String;

  p2: Integer;

begin

  if not RegQueryStringValue(HKCU, 'Environment', 'Path', P) then Exit;

  Acc := '';

  Rest := P;

  while Rest <> '' do

  begin

    p2 := Pos(';', Rest);

    if p2 = 0 then

    begin

      Item := Rest;

      Rest := '';

    end

    else

    begin

      Item := Copy(Rest, 1, p2 - 1);

      Rest := Copy(Rest, p2 + 1, Length(Rest));

    end;

    Item := Trim(Item);

    if Item <> '' then

    begin

      if Pos(';' + Lowercase(Item) + ';', ';' + Lowercase(Acc) + ';') = 0 then

      begin

        if Acc = '' then Acc := Item else Acc := Acc + ';' + Item;

      end;

    end;

  end;

  if Lowercase(Acc) <> Lowercase(P) then

    RegWriteExpandStringValue(HKCU, 'Environment', 'Path', Acc);

end;



procedure CurStepChanged(CurStep: TSetupStep);

var

  AppDir: String;

begin

  if CurStep = ssPostInstall then

  begin


    AppDir := ExpandConstant('{app}');

    ProvisionDshCommand();

    NormalizeUserPath();

    { The Electron shell itself needs the Win7 API layer (GetSystemTimePreciseAsFileTime). }

    EnableVxKex(AppDir + '\{#AppExe}');

    { Bundled runtimes need it too: node for sharp/libvips WaitOnAddress,

      python for the missing api-ms-win-core-path-l1-1-0.dll. }

    EnableVxKex(AppDir + '\resources\runtime\primary-runtime\dependencies\node\bin\node.exe');

    EnableVxKex(AppDir + '\resources\runtime\primary-runtime\dependencies\python\python.exe');

  // NOTE: IFEO for libreoffice-kit.exe is intentionally NOT set -- KexDll.dll cannot be resolved from the sidecar

// directory (it only works when KexDll sits next to the exe). Office conversion uses the soffice.com fallback instead.

  end;

end;



procedure CurUninstallStepChanged(CurUninstallStep: TUninstallStep);

begin

  if CurUninstallStep = usUninstall then

  begin

    RegDeleteKeyIncludingSubkeys(HKEY_LOCAL_MACHINE, KEX_KEY_ROOT + 'DeepSeek Harness.exe');

    RegDeleteKeyIncludingSubkeys(HKEY_LOCAL_MACHINE, KEX_KEY_ROOT + 'node.exe');

    RegDeleteKeyIncludingSubkeys(HKEY_LOCAL_MACHINE, KEX_KEY_ROOT + 'python.exe');

  end;

end;



{ ==================== Windows 7 environment check ==================== }

function DescribeWindows(const V: TWindowsVersion): String;

begin

  Result := Format('%d.%d (Build %d', [V.Major, V.Minor, V.Build]);

  if V.ServicePackMajor > 0 then

    Result := Result + Format(', Service Pack %d', [V.ServicePackMajor]);

  Result := Result + ')';

end;



var

  EnvText: String;

  EnvFatal: Boolean;

  EnvSha2Missing: Boolean;

  KbInstalled: Boolean;



function HasKBPackage(const KB: String): Boolean;

var

  Names: TArrayOfString;

  I: Integer;

  Prefix: String;

begin

  Result := False;

  Prefix := 'Package_for_' + KB;

  if RegGetSubkeyNames(HKLM64, 'SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\Packages', Names) then

    for I := 0 to GetArrayLength(Names) - 1 do

      if (CompareText(Copy(Names[I], 1, Length(Prefix)), Prefix) = 0) and
         (Length(Names[I]) > Length(Prefix)) and
         ((Copy(Names[I], Length(Prefix) + 1, 1) = '~') or (Copy(Names[I], Length(Prefix) + 1, 1) = '_')) then

      begin

        Result := True;

        Exit;

      end;

end;



function HasTls12: Boolean;

begin

  Result := RegKeyExists(HKLM, 'SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Client');

end;



function SecTitle(const S: String): String;

begin

  Result := #13#10 + '────── ' + S + ' ──────' + #13#10;

end;



function Row(const Mark, Name, Note: String): String;

begin

  Result := '   ' + Mark + '  ' + Name;

  if Note <> '' then

    Result := Result + '   ' + Note;

  Result := Result + #13#10;

end;



function KbFile(const FileName: String): String;

begin

  Result := ExpandConstant('{tmp}\kb\') + FileName;

end;



{ 仅当「系统里缺这个补丁」且「包里带了对应 MSU」时才安装。 }

function WantKb(const Kb, FileName: String): Boolean;

begin

  Result := (not HasKBPackage(Kb)) and FileExists(KbFile(FileName));

end;

{ ---- 更新执行标记：任一 [Run] 的 Check 通过就认为本次安装了更新 ---- }

function CheckDotNet: Boolean;

begin

  Result := not HasDotNet48;

  if Result then UpdateRan := True;

end;



function CheckPs51: Boolean;

begin

  Result := not HasPS51;

  if Result then UpdateRan := True;

end;



function Check7z: Boolean;

begin

  Result := not Has7z;

end;



function CheckGit: Boolean;

begin

  Result := not HasGit;

end;



function CheckLO: Boolean;

begin

  Result := not HasLibreOffice;

end;



function CheckKb4474419: Boolean;

begin

  Result := WantKb('KB4474419', 'Windows6.1-KB4474419-v3-x64.msu');

  if Result then UpdateRan := True;

end;



function CheckKb4490628: Boolean;

begin

  Result := WantKb('KB4490628', 'Windows6.1-KB4490628-x64.msu');

  if Result then UpdateRan := True;

end;



function CheckKb2533623: Boolean;

begin

  Result := WantKb('KB2533623', 'Windows6.1-KB2533623-x64.msu');

  if Result then UpdateRan := True;

end;



function CheckKb2670838: Boolean;

begin

  Result := WantKb('KB2670838', 'Windows6.1-KB2670838-x64.msu');

  if Result then UpdateRan := True;

end;



function CheckAnyKb: Boolean;

begin

  Result := CheckKb4474419 or CheckKb4490628 or CheckKb2533623 or CheckKb2670838;

end;



{ 安装后是否需要重启：CBS / WU / PendingFileRenameOperations 任一存在即需要。 }

function PendingReboot: Boolean;

begin

  Result :=

    RegKeyExists(HKLM, 'SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending') or

    RegKeyExists(HKLM, 'SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired') or

    RegValueExists(HKLM, 'SYSTEM\CurrentControlSet\Control\Session Manager', 'PendingFileRenameOperations');

end;



{ 只有「本次确实装了补丁」并且「确实待重启」才在完成页显示重启勾选。 }

function NeedRestartAfterPatch: Boolean;

begin

  Result := FileExists(ExpandConstant('{commonappdata}\\DeepSeekHarness\\kb-restart.needed'));

end;



function DoInitializeSetup(): Boolean;

var

  V: TWindowsVersion;

begin

  { 只做探测，不弹框；结果写进 EnvText，由「环境检测」页展示。 }

  EnvText := '';

  EnvFatal := False;

  EnvSha2Missing := False;

  KbInstalled := False;

  { 记录：系统缺失且包内带了 MSU 时，标记「本次装过补丁」 }

  if WantKb('KB4474419', 'Windows6.1-KB4474419-v3-x64.msu') or

     WantKb('KB4490628', 'Windows6.1-KB4490628-x64.msu') or

     WantKb('KB2533623', 'Windows6.1-KB2533623-x64.msu') or

     WantKb('KB2670838', 'Windows6.1-KB2670838-x64.msu') then

    KbInstalled := True;



  Result := True;



  GetWindowsVersionEx(V);



  { ---- 一、系统版本 ---- }

  EnvText := EnvText + SecTitle('一、系统版本');

  EnvText := EnvText + Row('[系统]', DescribeWindows(V), '');

  if (V.Major <> 6) or (V.Minor <> 1) then

  begin

    EnvFatal := True;

    EnvText := EnvText + Row('[×]', '系统类型', '本包为 Windows 7 SP1 兼容版，当前不是 Windows 7');

  end

  else if V.ServicePackMajor < 1 then

  begin

    EnvFatal := True;

    EnvText := EnvText + Row('[×]', 'Service Pack 1', '未安装，.NET 4.8 与 PowerShell 5.1 无法安装');

  end

  else

    EnvText := EnvText + Row('[√]', '兼容性判定', '符合要求（Windows 7 SP1）');



  { ---- 二、运行库与工具链 ---- }

  EnvText := EnvText + SecTitle('二、运行库与工具链');

  if HasDotNet48 then EnvText := EnvText + Row('[√]', '.NET Framework 4.8', '已安装')

  else EnvText := EnvText + Row('[×]', '.NET Framework 4.8', '缺失，将随「先决包」组件安装');

  if HasPS51 then EnvText := EnvText + Row('[√]', 'PowerShell 5.1', '已安装')

  else EnvText := EnvText + Row('[×]', 'PowerShell 5.1', '缺失，将随「先决包」组件安装');

  if Has7z then EnvText := EnvText + Row('[√]', '7-Zip', '已安装')

  else EnvText := EnvText + Row('[ ]', '7-Zip', '未安装，属可选工具链');

  if HasGit then EnvText := EnvText + Row('[√]', 'Git for Windows', '已安装')

  else EnvText := EnvText + Row('[ ]', 'Git for Windows', '未安装，属可选工具链');

  if HasLibreOffice then EnvText := EnvText + Row('[√]', 'LibreOffice', '已安装')

  else EnvText := EnvText + Row('[ ]', 'LibreOffice', '未安装；Office 预览/PDF 需要');



  { ---- 三、系统补丁 ---- }

  EnvText := EnvText + SecTitle('三、系统补丁（Win7 停更后的前置条件）');

  if HasKBPackage('KB4474419') then

    EnvText := EnvText + Row('[√]', 'KB4474419', 'SHA-2 代码签名支持')

  else

  begin

    EnvSha2Missing := True;

    EnvText := EnvText + Row('[!]', 'KB4474419', '缺失：SHA-2 签名支持，强建议先装，否则 .NET/Git 可能报签名无效');

  end;

  if HasKBPackage('KB4490628') then

    EnvText := EnvText + Row('[√]', 'KB4490628', 'SHA-2 服务栈更新')

  else

    EnvText := EnvText + Row('[!]', 'KB4490628', '缺失：与 KB4474419 配套');

  if HasKBPackage('KB2533623') then

    EnvText := EnvText + Row('[√]', 'KB2533623', 'SetDefaultDllDirectories')

  else

    EnvText := EnvText + Row('[!]', 'KB2533623', '缺失：可能影响部分 DLL 加载');

  if HasKBPackage('KB2670838') then

    EnvText := EnvText + Row('[√]', 'KB2670838', 'Platform Update（D2D/DWrite/D3D11.1）')

  else

    EnvText := EnvText + Row('[ ]', 'KB2670838', '缺失：默认软件渲染不依赖；改用 DSH_WIN7_GPU=1 时需要');

  if HasTls12 then

    EnvText := EnvText + Row('[√]', 'TLS 1.2 客户端', '可用于登录与在线更新')

  else

    EnvText := EnvText + Row('[!]', 'TLS 1.2 客户端', '缺失（KB3140245+注册表），登录/更新可能失败');



  { ---- 四、兼容层与潜在冲突 ---- }

  EnvText := EnvText + SecTitle('四、兼容层与潜在冲突');

  if RegKeyExists(HKLM, 'SOFTWARE\VxKex') or RegKeyExists(HKLM, 'SOFTWARE\WOW6432Node\VxKex') or

     FileExists(ExpandConstant('{sys}\KexDll.dll')) then

    EnvText := EnvText + Row('[√]', 'VxKex 兼容层', '已存在，本包会复用')

  else

    EnvText := EnvText + Row('[ ]', 'VxKex 兼容层', '未安装，将随包安装运行库');

  if FileExists(ExpandConstant('{sys}\VBoxHook.dll')) or FileExists(ExpandConstant('{sys}\AcLayers.dll')) then

    EnvText := EnvText + Row('[!]', '兼容性 shim', '检测到 VBoxHook/AcLayers；若曾手工开过“兼容模式”建议关闭');

  if RegValueExists(HKLM, 'SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\DeepSeek Harness.exe', 'UseFilter') then

    EnvText := EnvText + Row('[!]', '已有 IFEO 项', '安装时按当前路径重写');



  EnvText := EnvText + #13#10 +

    '说明：标记含义 —— [√] 已满足　[!] 建议补齐　[ ] 可选/未安装　[×] 影响功能' + #13#10;

end;



var

  HasPrev: Boolean;

  PrevVer: String;

  EnvPage: TOutputMsgMemoWizardPage;

  UpgPage: TOutputMsgMemoWizardPage;





function IsDshRunning(): Boolean;

var

  Code: Integer;

  OutFile: String;

  Data: AnsiString;

begin

  OutFile := ExpandConstant('{tmp}\dshproc.txt');

  DeleteFile(OutFile);

  Exec(ExpandConstant('{cmd}'), '/c tasklist /fi "imagename eq DeepSeek Harness.exe" /fo csv /nh > "' + OutFile + '"', '', SW_HIDE, ewWaitUntilTerminated, Code);

  Result := False;

  if FileExists(OutFile) then

    if LoadStringFromFile(OutFile, Data) then

      Result := Pos('DeepSeek', String(Data)) > 0;

  DeleteFile(OutFile);

end;



function PrepareToInstall(var NeedsRestart: Boolean): String;

var

  Code: Integer;

begin

  { 覆盖安装前：先询问，再关闭正在运行的实例，避免文件被占用导致覆盖失败。 }

  if IsDshRunning() then

  begin

    if (not WizardSilent) and (MsgBox('检测到 DeepSeek Harness 正在运行。继续安装会强制关闭它，未保存的对话与编辑内容将会丢失。' + #13#10#13#10 + '请先保存好正在进行的工作，然后再继续。' + #13#10#13#10 + '现在立即关闭并继续安装吗？', mbConfirmation, MB_YESNO) <> IDYES) then

    begin

      Result := '安装已取消：请先手动退出 DeepSeek Harness，然后重新运行安装程序。';

      Exit;

    end;

  end;

  Exec('taskkill.exe', '/f /im "DeepSeek Harness.exe"', '', SW_HIDE, ewWaitUntilTerminated, Code);

  Exec('taskkill.exe', '/f /im "dsh.exe"', '', SW_HIDE, ewWaitUntilTerminated, Code);

  Sleep(1200);

  Result := '';

end;



function InitializeSetup(): Boolean;

var

  Sub: String;

begin

  Result := DoInitializeSetup();



  Sub := 'SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\' +

         '{8F3C1A2E-5D7B-4E9A-9C21-5A1B2C3D4E5F}_is1';

  PrevVer := '';

  if RegQueryStringValue(HKEY_LOCAL_MACHINE, Sub, 'DisplayVersion', PrevVer) then

    HasPrev := True

  else if RegQueryStringValue(HKEY_CURRENT_USER, Sub, 'DisplayVersion', PrevVer) then

    HasPrev := True

  else

    HasPrev := RegValueExists(HKEY_LOCAL_MACHINE, Sub, 'UninstallString');

end;



procedure InitializeWizard();

var

  UpgText: String;

begin

  EnvPage := CreateOutputMsgMemoPage(wpWelcome,

    '环境检测', '安装程序已检测本机环境，请确认后再继续。',

    '检测结果：', EnvText);



  UpgText := '【重要】覆盖安装会先关闭正在运行的 DeepSeek Harness。请先保存好正在进行的工作（对话、未提交的文件修改），再继续安装。' + #13#10#13#10 + '检测到本机已安装 DeepSeek Harness ' + PrevVer + '。' + #13#10#13#10 +

             '本次安装为覆盖升级，目标版本：' + '{#AppVersion}' + #13#10#13#10 +

             '升级行为：' + #13#10 +

             '  - 程序文件被替换为新版本；' + #13#10 +

             '  - 你的会话、工作区与登录凭证保存在 %APPDATA%\@deepseek-ai\dsh-desktop' + #13#10 +

             '    与 %LOCALAPPDATA%\DeepSeek Harness，不会被删除；' + #13#10 +

             '  - 已启用的 VxKex 兼容层配置会按新路径重写。' + #13#10#13#10 +

             '如果你希望保留旧版本，请先退出并使用控制面板卸载旧版本。';



  UpgPage := CreateOutputMsgMemoPage(EnvPage.ID,

    '覆盖安装', '本机已有 DeepSeek Harness，安装程序将执行覆盖升级。',

    '升级信息：', UpgText);

end;



function ShouldSkipPage(PageID: Integer): Boolean;

begin

  Result := (PageID = UpgPage.ID) and (not HasPrev);

end;



var

  AutostartCheck: TCheckBox;



function NextButtonClick(CurPageID: Integer): Boolean;

begin

  if CurPageID = wpFinished then

  begin

    if Assigned(AutostartCheck) and AutostartCheck.Checked then

      RegWriteStringValue(HKCU, 'Software\Microsoft\Windows\CurrentVersion\Run', 'DeepSeekHarness', '"' + ExpandConstant('{app}\{#AppExe}') + '"');

    Result := True;

    Exit;

  end;

  Result := True;

  if CurPageID = EnvPage.ID then

  begin

    if EnvFatal then

    begin

      MsgBox('检测到阻塞性问题，无法继续安装。' + #13#10#13#10 +

             '请先安装 Windows 7 Service Pack 1（或改用 Windows 7 SP1 机器）后重试。',

             mbCriticalError, MB_OK);

      Result := False;

      Exit;

    end;

    if EnvSha2Missing then

    begin

      if MsgBox('检测到本机缺少 KB4474419（SHA-2 代码签名支持）。' + #13#10#13#10 +

                '现在多数安装包（.NET 4.8、Git 等）使用 SHA-2 签名，缺少该补丁时它们可能安装失败。' + #13#10#13#10 +

                '仍要继续吗？',

                mbConfirmation, MB_YESNO) = IDNO then

      begin

        Result := False;

        Exit;

      end;

    end;

  end;

end;



{ ---- 语言自适应：授权页单选文案 + 改动说明页正文 ---- }

function WinUILanguage(): Integer; external 'GetUserDefaultUILanguage@kernel32.dll stdcall';







procedure CurPageChanged(CurPageID: Integer);

begin

  if CurPageID = wpInfoBefore then



  begin

    if (WinUILanguage() and $3FF) = $04 then

    begin

      ExtractTemporaryFile('CHANGES-WIN7.zh.ansi.txt');

      WizardForm.InfoBeforeMemo.Lines.LoadFromFile(ExpandConstant('{tmp}\CHANGES-WIN7.zh.ansi.txt'));

    end;

  end;

end;

