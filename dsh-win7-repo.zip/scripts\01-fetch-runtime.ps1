<#
.SYNOPSIS  Download the electron-legacy runtime that still loads on Windows 7.
.DESCRIPTION
  electron-legacy (Alex313031) ships a Chromium/Electron build whose PE
  subsystem version is 5.2, so the Windows 7 loader accepts it - the only
  reason this port is possible at all.
  Produces:  build\runtime\electron.exe  (renamed later by 04-assemble.ps1)
#>
[CmdletBinding()]
param(
  [string]$Version = "44.10.2",
  [string]$OutDir  = "$PSScriptRoot\..\build\runtime",
  [string]$LocalZip
)
$ErrorActionPreference = "Stop"
New-Item -ItemType Directory -Force -Path $OutDir | Out-Null

if ($LocalZip) {
  $zip = $LocalZip
  if (-not (Test-Path $zip)) { throw "LocalZip not found: $zip" }
} else {
  $asset = "electron-v$Version-win32-x64.zip"
  $url   = "https://github.com/Alex313031/electron-legacy/releases/download/v$Version/$asset"
  $zip   = Join-Path $OutDir $asset
  if (-not (Test-Path $zip)) {
    Write-Host "[1/2] downloading $url"
    Invoke-WebRequest -Uri $url -OutFile $zip -UseBasicParsing
  } else { Write-Host "[1/2] cached $zip" }
}

Write-Host "[2/2] extracting"
Expand-Archive -Path $zip -DestinationPath $OutDir -Force
$exe = Get-ChildItem $OutDir -Filter electron.exe -Recurse | Select-Object -First 1
if (-not $exe) { throw "electron.exe not found in $OutDir" }

# sanity: PE subsystem must be 5.2, otherwise Win7 will refuse to start it
$bytes = [IO.File]::ReadAllBytes($exe.FullName)
$pe    = [BitConverter]::ToInt32($bytes, 0x3C)
$magic = [BitConverter]::ToUInt16($bytes, $pe + 24)
$sub   = if ($magic -eq 0x20B) { [BitConverter]::ToUInt16($bytes, $pe + 24 + 0x48) } else { [BitConverter]::ToUInt16($bytes, $pe + 24 + 0x48) }
$osv   = if ($magic -eq 0x20B) { [BitConverter]::ToUInt16($bytes, $pe + 24 + 0x40) } else { [BitConverter]::ToUInt16($bytes, $pe + 24 + 0x40) }
Write-Host ("     OSVersion={0}.{1} SubsystemVersion={2}.{3}  ({4:N0} B)" -f ($osv -shr 8),($osv -band 0xFF),($sub -shr 8),($sub -band 0xFF),$bytes.Length)
if ($sub -gt 0x0601) { Write-Warning "subsystem > 6.1 - this binary will NOT load on Windows 7" }
Write-Host "OK -> $($exe.FullName)"
