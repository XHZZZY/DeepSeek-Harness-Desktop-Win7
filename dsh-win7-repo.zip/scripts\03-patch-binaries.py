#!/usr/bin/env python3
"""Patch prebuilt native addons so they accept the electron-legacy runtime.

The node-addon-require-builtin prebuilt embeds a V8 version string and a
Node ABI triple.  electron-legacy 44.10.2 reports 15.2.124.45-electron.0 /
node 24.22.2, so both must be rewritten in place (same byte length).

Usage: python 03-patch-binaries.py <payload-dir>
"""
import sys, pathlib

FIND = b"15.2.124.28-electron.0"
REPL = b"15.2.124.45-electron.0"
TRIPLES = [(24, 21, 0), (24, 22, 2)]

def patch_node_file(p):
    b = bytearray(p.read_bytes())
    n = b.count(FIND)
    if n:
        b = bytearray(bytes(b).replace(FIND, REPL))
    hit = 0
    for old_t, new_t in [(TRIPLES[0], TRIPLES[1])]:
        old = (old_t[0] | old_t[1] << 8 | old_t[2] << 16).to_bytes(4, "little")
        new = (new_t[0] | new_t[1] << 8 | new_t[2] << 16).to_bytes(4, "little")
        while True:
            i = bytes(b).find(old)
            if i < 0:
                break
            b[i:i + 4] = new
            hit += 1
    if n or hit:
        p.write_bytes(bytes(b))
    print(f"  {p.name}: v8 strings={n} abi triples={hit}")

def main():
    root = pathlib.Path(sys.argv[1])
    hits = list(root.rglob("node-addon-require-builtin*.node")) + list(root.rglob("*-napi-v9.node"))
    seen = set()
    for p in hits:
        if p in seen:
            continue
        seen.add(p)
        patch_node_file(p)
    if not seen:
        print("  !! no addon prebuilt found")

if __name__ == "__main__":
    main()
