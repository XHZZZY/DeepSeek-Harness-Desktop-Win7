<#
.SYNOPSIS  One-shot build: fetch -> patch -> assemble -> installer.
.EXAMPLE
  .\build.ps1                       # full build from upstream
  .\build.ps1 -SkipFetch            # reuse build\app and build\runtime
  .\build.ps1 -RuntimeZip D:\electron-v44.10.2-win32-x64.zip -PayloadExe D:\setup.exe
#>
[CmdletBinding()]
param(
  [string]$ElectronVersion = "44.10.2",
  [string]$RuntimeZip,
  [string]$PayloadExe,
  [string]$Rcedit,
  [switch]$SkipFetch
)
$ErrorActionPreference = "Stop"
$Root  = (Resolve-Path "$PSScriptRoot\..").Path
$Build = Join-Path $Root "build"
$Py    = if ($env:PYTHON) { $env:PYTHON } else { "python" }
New-Item -ItemType Directory -Force -Path $Build | Out-Null

function Step($n,$t){ Write-Host "`n=== $n. $t ===" -ForegroundColor Cyan }

if (-not $SkipFetch) {
  Step 1 "runtime (electron-legacy)"
  & "$PSScriptRoot\01-fetch-runtime.ps1" -Version $ElectronVersion -LocalZip $RuntimeZip
  Step 2 "official payload"
  & "$PSScriptRoot\02-fetch-payload.ps1" -LocalExe $PayloadExe
}

Step 3 "apply source patches"
$extract = Join-Path $Build "extract"
if (Test-Path $extract) { Remove-Item $extract -Recurse -Force }
New-Item -ItemType Directory -Force -Path $extract | Out-Null
Copy-Item (Join-Path $Build "app\resources\app.asar.unpacked\lib\main.js") $extract -ErrorAction SilentlyContinue
# official files are extracted from app.asar by the script below
& $Py "$PSScriptRoot\extract-asar.py" (Join-Path $Build "app\resources\app.asar") $extract
& $Py "$PSScriptRoot\apply-patches.py" (Join-Path $Root "patches") $extract
if ($LASTEXITCODE -ne 0) { throw "patch failed" }

Step 4 "patch native addons"
& $Py "$PSScriptRoot\03-patch-binaries.py" (Join-Path $Build "app")

Step 5 "rebuild app.asar"
& $Py "$PSScriptRoot\patch-asar.py" (Join-Path $Build "app\resources\app.asar") $extract `
      (Join-Path $Build "app\resources\app.asar") (Join-Path $Build "app\resources\app.asar.unpacked")
if ($LASTEXITCODE -ne 0) { throw "asar rebuild failed" }

Step 6 "assemble payload"
& "$PSScriptRoot\04-assemble.ps1" -Rcedit $Rcedit

Step 7 "verify"
& "$PSScriptRoot\verify.ps1"

Step 8 "installer"
& "$PSScriptRoot\05-build-installer.ps1"

Write-Host "`nDONE." -ForegroundColor Green
