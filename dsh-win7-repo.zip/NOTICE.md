# NOTICE

This repository is a **compatibility patch set**, not a fork of DeepSeek Harness.

* No upstream binary, no `app.asar`, no Electron runtime and no installer payload is
  redistributed here. `scripts/01-fetch-runtime.ps1` and `scripts/02-fetch-payload.ps1`
  download them from their official distribution channels at build time.
* `patches/*.patch` contain only the hunks this port changes, with the minimum context
  lines required for a valid unified diff. The surrounding code remains the property of
  its original authors (DeepSeek / Electron / Chromium contributors).
* Files under `files/` are original work of this port, except:
  * `files/installer/chinese.isl` — derived from Inno Setup’s Chinese translation
    (Inno Setup licence).
  * `files/licenses/*` — third-party licence texts, reproduced verbatim.
* **VxKex API Extensions** (installed optionally by the installer) is published upstream
  with `license: null`, i.e. *all rights reserved*. It is not included in this repository;
  the installer downloads / bundles it separately at build time.

Trademarks belong to their owners. “DeepSeek” is used descriptively only.
