#!/usr/bin/env python3
"""Extract files from an asar archive (header offsets are relative to dataStart)."""
import sys, json, struct, pathlib

def main():
    src, out = pathlib.Path(sys.argv[1]), pathlib.Path(sys.argv[2])
    b = src.read_bytes()
    magic, hdr, str_size, json_size = struct.unpack("<IIII", b[:16])
    assert magic == 4, f"bad asar magic {magic} (expected 4)"
    data_start = 8 + hdr
    header = json.loads(b[16:16 + json_size].decode("utf-8"))

    def walk(node, prefix=""):
        for name, e in node.get("files", {}).items():
            p = prefix + "/" + name
            if "files" in e:
                yield from walk(e, p)
            else:
                yield p, e

    n = 0
    for p, e in walk(header):
        if e.get("unpacked"):
            continue
        off, size = int(e.get("offset", 0)), int(e.get("size", 0))
        dst = out / p.lstrip("/")
        dst.parent.mkdir(parents=True, exist_ok=True)
        dst.write_bytes(b[data_start + off: data_start + off + size])
        n += 1
    print(f"extracted {n} files -> {out}")

if __name__ == "__main__":
    main()
