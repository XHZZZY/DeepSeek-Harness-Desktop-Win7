@echo off
setlocal enabledelayedexpansion
set "LOGDIR=%ProgramData%\DeepSeekHarness"
if not exist "%LOGDIR%" md "%LOGDIR%" >nul 2>&1
set "LOG=%LOGDIR%\kb-install.log"
set "WORK=%TEMP%\dshkb"
if exist "%LOGDIR%\kb-restart.needed" del /f /q "%LOGDIR%\kb-restart.needed"
>>"%LOG%" echo [%DATE% %TIME%] ==== install-kb.cmd v2 start ====
call :one KB4490628
call :one KB4474419
call :one KB2533623
call :one KB2670838
>>"%LOG%" echo [%DATE% %TIME%] ==== install-kb.cmd v2 done ====
endlocal
exit /b 0

:one
set "F="
for %%F in ("%~dp0*%~1*.msu") do set "F=%%~fF"
if not defined F (
  >>"%LOG%" echo [%DATE% %TIME%] skip %~1 msu-not-found
  goto :eof
)
>>"%LOG%" echo [%DATE% %TIME%] begin %~1
"%SystemRoot%\System32\wusa.exe" "!F!" /quiet /norestart
set "RC=!ERRORLEVEL!"
>>"%LOG%" echo [%DATE% %TIME%]  wusa exit=!RC!
if "!RC!"=="0" goto :eof
if "!RC!"=="3010" goto :mark
if "!RC!"=="1641" goto :mark
if exist "%WORK%" rd /s /q "%WORK%"
md "%WORK%" >nul 2>&1
expand -F:* "!F!" "%WORK%" >nul 2>&1
for %%C in ("%WORK%\*.cab") do (
  "%SystemRoot%\System32\dism.exe" /online /add-package /packagepath:"%%~fC" /quiet /norestart /LogPath:"%LOGDIR%\dism.log"
  set "RC2=!ERRORLEVEL!"
  >>"%LOG%" echo [%DATE% %TIME%]  dism %%~nxC exit=!RC2!
  if "!RC2!"=="3010" echo 1>"%LOGDIR%\kb-restart.needed"
  if "!RC2!"=="1641" echo 1>"%LOGDIR%\kb-restart.needed"
)
goto :eof

:mark
echo 1>"%LOGDIR%\kb-restart.needed"
goto :eof