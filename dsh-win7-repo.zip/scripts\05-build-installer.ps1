<#
.SYNOPSIS  Compile the Inno Setup script into the final installer.
#>
[CmdletBinding()]
param(
  [string]$Root = "$PSScriptRoot\..",
  [string]$Iss  = "$PSScriptRoot\..\files\installer\dsh_win7.iss",
  [string]$Iscc = "C:\Program Files (x86)\Inno Setup 6\ISCC.exe"
)
$ErrorActionPreference = "Stop"
if (-not (Test-Path $Iscc)) { throw "ISCC not found: $Iscc" }

$work = "$PSScriptRoot\..\build"
Write-Host "[1/2] copying installer assets"
Copy-Item (Join-Path $Root "files\installer\chinese.isl") $work -Force
Copy-Item (Join-Path $Root "files\installer\wizard.bmp")  $work -Force
Copy-Item (Join-Path $Root "files\installer\small.bmp")   $work -Force

Write-Host "[2/2] ISCC"
$sw = [Diagnostics.Stopwatch]::StartNew()
& $Iscc "/Qp" "/O$work\output" "/FDeepSeekHarness-win7-x64-Setup" $Iss
$sw.Stop()
if ($LASTEXITCODE -ne 0) { throw "ISCC failed with $LASTEXITCODE" }
$out = Get-ChildItem "$work\output" -Filter "*.exe" | Sort-Object LastWriteTime | Select-Object -Last 1
Write-Host ("OK -> {0}  ({1:N0} B, {2:N0} s)" -f $out.FullName,$out.Length,$sw.Elapsed.TotalSeconds)
